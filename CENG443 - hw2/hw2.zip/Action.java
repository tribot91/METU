/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Akpak
 */
public enum Action {
    TRANSPORTER_CREATED,
    TRANSPORTER_TRAVEL,
    TRANSPORTER_TAKE_INGOT,
    TRANSPORTER_DROP_INGOT,
    TRANSPORTER_STOPPED,
    SMELTER_CREATED,
    SMELTER_STARTED,
    SMELTER_FINISHED,
    SMELTER_STOPPED,
    CONSTRUCTOR_CREATED,
    CONSTRUCTOR_STARTED,
    CONSTRUCTOR_FINISHED,
    CONSTRUCTOR_STOPPED
}
